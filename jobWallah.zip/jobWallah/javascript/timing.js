


function timing() {
    let count = 1;
    let timeInSecond = document.getElementById("timeInSecond");
    setInterval(() => {

        for (let i = 1; i <= 1; i++) {  
            // timeInSecond.innerHTML = count++;
        }

    }, 1000);

}

timing()